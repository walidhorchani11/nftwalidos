export const data = [
    {
        id: 1,
        description: 'K2lis هي شركة متخصصة في تقنيات البلوك تشين والبرمجيات المتقدمة',
        imageSrc: 'logo-k2lis.png',
        links: {
            fb: '',
            twitter:'',
            youtube: '',
            instagram: ''
        }
    },
        
    {
        id: 2,
        description: 'المنظمة العربية للتربية والثقافة والعلوم',
        imageSrc: 'logo-alecso.png',
        links: {
            facebook: '',
            twitter:'',
            youtube: '',
            linkedin: ''
        }
    },
    {
        id: 3,
        description: 'منصة الألكسو التعليمية للـNFT لتعليم الناشئة في العالم العربي على إنشاء رموز الـNFT وكيفية تداولها بالبيع والشراء باستعمال عملة رقمية "ألكسو كوين" في بيئة آمنة.',
        imageSrc: 'logo_nft.png',
        links: {
            fb: '',
            twitter:'',
            youtube: '',
            instagram: ''
        }
    }
]